#pragma once

#include <jni.h>

class SteamUtils {
public:
    static void log(const char* format, ...);
};
