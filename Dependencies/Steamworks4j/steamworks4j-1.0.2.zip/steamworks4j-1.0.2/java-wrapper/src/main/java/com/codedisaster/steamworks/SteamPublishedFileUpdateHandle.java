package com.codedisaster.steamworks;

public class SteamPublishedFileUpdateHandle extends SteamNativeHandle {

	SteamPublishedFileUpdateHandle(long handle) {
		super(handle);
	}
}
