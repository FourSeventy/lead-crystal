package com.codedisaster.steamworks;

public class SteamLeaderboardHandle extends SteamNativeHandle {

	SteamLeaderboardHandle(long handle) {
		super(handle);
	}
}
