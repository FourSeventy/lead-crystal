package com.codedisaster.steamworks;

public class SteamLeaderboardEntriesHandle extends SteamNativeHandle {

	SteamLeaderboardEntriesHandle(long handle) {
		super(handle);
	}
}
