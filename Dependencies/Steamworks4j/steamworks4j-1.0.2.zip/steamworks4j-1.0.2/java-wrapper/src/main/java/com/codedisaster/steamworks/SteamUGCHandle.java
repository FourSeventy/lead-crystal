package com.codedisaster.steamworks;

public class SteamUGCHandle extends SteamNativeHandle {

	public SteamUGCHandle(long handle) {
		super(handle);
	}
}
